package com.demo.interfaces;

public interface Interface2 {
	int compare(int x,int y);

}
