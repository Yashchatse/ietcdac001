package com.demo.interfaces;

public interface MyGenericInterface<T> {
	T add(T x,T y,T ...arr);

}
